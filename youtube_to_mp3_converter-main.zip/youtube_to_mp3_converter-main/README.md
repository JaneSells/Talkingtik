# Youtube to MP3 Converter
![image](https://github.com/sarthakvs/Youtube-to-mp3-converter/assets/98168713/21cce579-a568-4fcb-aa05-933ce2b609cb)
Enter the URL of the YouTube video you want to convert, and the application will extract the audio track and provide it as a downloadable MP3 file.

## Usage

1. Visit the [YT2MP3 website](https://yt2mp3-magic.onrender.com).
2. Paste the URL of the YouTube video you want to convert.
3. Click on the "Convert" button.
4. Once the conversion is complete, download the MP3 file and enjoy your favorite content offline!

## Installation
There's no installation required for this web application. Simply visit the website and start converting YouTube videos to MP3 files hassle-free!
